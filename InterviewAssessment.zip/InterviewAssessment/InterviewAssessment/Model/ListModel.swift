//
//  ListModel.swift
//  InterviewAssessment
//
//  Created by Test on 22/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import Foundation
struct ListModel {
    var id: Int?
    var author: String?
    var imageUrl: String?
    init(dictionary: NSDictionary) {
        self.id = dictionary["id"] as? Int ?? 0
        self.author = dictionary["author"] as? String ?? ""
        self.imageUrl = Constants.URLStrings.imgUrl + String(dictionary["id"] as? Int ?? 0)
    }
}
