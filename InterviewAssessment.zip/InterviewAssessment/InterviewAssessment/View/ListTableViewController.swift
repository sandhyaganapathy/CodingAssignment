//
//  ListTableViewController.swift
//  InterviewAssessment
//
//  Created by Sandhya Ganapathy on 22/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import UIKit
import SDWebImage
class ListTableViewController: UITableViewController {
    //Cell Identifier
    let cellIdentifier: String = "CellIdentifier"
    var listViewModel = ListViewModel()
    let myActivityIndicator = UIActivityIndicatorView()
    var placeholderImage: UIImage = {
        let placeholderImg = UIImage(named: "no_Image")
        return placeholderImg!
    }()
    // MARK: - ViewController Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Images"
        //TableView Property setting
        self.tableView.rowHeight = 100
        self.tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: cellIdentifier)
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        // Activity Indicator
        self.myActivityIndicator.center = self.view.center
        self.myActivityIndicator.hidesWhenStopped = true
        if #available(iOS 13.0, *) {
            self.myActivityIndicator.style = .medium
        } else {
            // Fallback on earlier versions
            self.myActivityIndicator.style = .gray
        }
        self.view.addSubview(myActivityIndicator)
        self.myActivityIndicator.startAnimating()
        // Webservice Call
        self.callApiToGetJSONData()
    }
    // MARK: - API Calls
    func callApiToGetJSONData() {
        if Reachability.isConnectedToNetwork() {
            let urlString = URL(string: Constants.URLStrings.webServiceUrlString)
            let urlRequest = URLRequest(url: urlString!)
            listViewModel.fetchJsonAndSaving(urlRequest: urlRequest, completion: {(successOrFailure, responseObject) in
                if successOrFailure {
                    DispatchQueue.main.async {
                        print(responseObject!)
                        self.tableView.reloadData()
                        self.myActivityIndicator.stopAnimating()
                    }
                } else {
                    //Failure Case
                    self.myActivityIndicator.stopAnimating()
                }
            })
        } else {
            self.myActivityIndicator.stopAnimating()
            let msgString = "No Internet connection.Please check your network connection"
            let alertController = UIAlertController(title: "",
                                                    message: msgString, preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
        }
    }
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  listViewModel.numberOfRowsInSection()
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: cellIdentifier)
        }
        let model = listViewModel.itemsArray[indexPath.row] as ListModel
        if let imgURLString = model.imageUrl {
            let imageUrl = URL(string: imgURLString)
            cell?.imageView?.sd_setShowActivityIndicatorView(true)
            if #available(iOS 13.0, *) {
                cell?.imageView?.sd_setIndicatorStyle(.medium)
            } else {
                // Fallback on earlier versions
                cell?.imageView?.sd_setIndicatorStyle(.gray)
            }
            cell?.imageView?.sd_setImage(with: imageUrl, placeholderImage: placeholderImage,
                                      options: .forceTransition, completed: nil)
            cell?.textLabel?.text = listViewModel.itemsArray[indexPath.row].author
            cell?.selectionStyle = .none
            return cell ?? UITableViewCell()
        }
        return UITableViewCell()
    }
}
