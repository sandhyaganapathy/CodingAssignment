//
//  Constants.swift
//  InterviewAssessment
//
//  Created by Sandhya Ganapathy on 22/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

struct Constants {
    // MARK: - API Related URLs
    struct URLStrings {
        static let webServiceUrlString = "https://picsum.photos/list"
        static let imgUrl = "https://picsum.photos/200/300?image="
    }
}
