//
//  ListViewModel.swift
//  InterviewAssessment
//
//  Created by Test on 22/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import Foundation
class ListViewModel: NSObject {
    var itemsArray = [ListModel]()
    // MARK: - APIClient call
    func fetchJsonAndSaving(urlRequest: URLRequest,
                            completion: @escaping (_ success: Bool, _ object: [[String: Any]]?) -> () ) {
        APIClient.client.fetchDataTask(urlRequest: urlRequest, completion: { (successOrFailure, responseObject) in
            if successOrFailure {
                if let responseObj = responseObject as? [[String: Any]] {
                        completion(true, responseObj)
                        for item in responseObj {
                            let model = ListModel(dictionary: item as NSDictionary )
                            self.itemsArray.append(model)
                    }
                }
            }
        })
    }
    // MARK: - To Get Row Count
    func numberOfRowsInSection() -> Int {
        return itemsArray.count
    }
}
